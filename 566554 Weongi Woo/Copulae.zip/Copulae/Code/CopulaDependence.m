clc
clear all
tic

data=xlsread('data_Copula.xlsx','LogReturn','B:K');  % stock daily log return data
Size=xlsread('data_Copula.xlsx','Size','B:B');                % firm size
[T,N]=size(data);
Return=data*100; % Log return expressed in percentage

% Limiting the period of analysis from 2008 to 2009
Y=756;
h=505;  % backward period for estimating GARCH residuals
Temp=Return((Y-h):(Y-1),:);
DeMeanReturn=Temp-repmat(mean(Temp),h,1);

Par=zeros(N,3);   % p,o,q  where marginal is normal cdf
% Par=zeros(N,4);   % p,o,q  where marginal is t cdf
Ht=zeros(h,N);

% GARCH estimation
for i=1:N     
    [Par(i,:), LL, Ht(:,i)]=tarch(DeMeanReturn(:,i),1,0,1);    % error distribution as default "Normal"
%[Par(i,:), LL, Ht(:,i)]=tarch(DeMeanReturn(:,i),1,0,1,'STUDENTST'); 
end

Residuals=DeMeanReturn./sqrt(Ht);

%%%%  Estimate dependence parameters in copula density   %%%% 
theta = zeros(N,N);         %Parameter for Gaussian Copula 
theta_t = zeros(N,N);       %Parameter for Student's t Copula
nu = zeros(N,N);            %Degrees of freedom parameter for Student's t Copula
theta_Clay = zeros(N,N);    %Parameter for Clayton Copula
theta_Gum = zeros(N,N);     %Parameter for Gumbel Copula
theta_Frank = zeros(N,N);   %Parameter for Frank Copula
tau_Clay = zeros(N,N);      %Kendall's tau based on Clayton Copula
tau_Gum = zeros(N,N);       %Kendall's tau based on Gumbel Copula
tau_Frank = zeros(N,N);     %Kendall's tau based on Fank Copula
tail_Upper = zeros(N,N);    %Upper tail dependence based on Gumbel Copula
tail_Lower = zeros(N,N);    %Lower tail dependence based on Clayton Copula


 for i=1:N
       V=normcdf(Residuals(:,i));       
        for j=(i+1):N    
            U=[normcdf(Residuals(:,j)), V];
            K=  copulafit('Gaussian',U);
            theta(j,i)=K(1,2);
            [K, P]=  copulafit('t',U);
            [ theta_t(j,i) ]=K(1,2);
            nu(j,i)=P;
            theta_Clay(j,i) =  copulafit('Clayton',U);
            theta_Gum(j,i) =  copulafit('Gumbel',U);
            theta_Frank(j,i) = copulafit('Frank',U);
             tau_Clay(j,i)    =   theta_Clay(j,i)/( theta_Clay(j,i)+2);   %relate Clayton dependence to kendall tau
             tau_Gum(j,i)     =   1-1/theta_Gum(j,i);                     %relate Gumbel dependence to kendall tau
             tau_Frank(j,i)   =   1-4*(1-debye1(theta_Frank(j,i)))/theta_Frank(j,i);  %relate Frank dependence to kendall tau
             tail_Upper(j,i)  =   2-2^(1/theta_Gum(j,i));                 % uppper tail dependence from Gumbel
             tail_Lower(j,i)  =   2^(-1/theta_Clay(j,i));                  % Lower tail dependence from Clayton
             
             %Symmetric dependence between i and j
             theta(i,j)=theta(j,i);
             theta_t(i,j)=theta_t(j,i);
             theta_Clay(i,j)=theta_Clay(j,i);
             theta_Gum(i,j)=theta_Gum(j,i);
             theta_Frank(i,j)=theta_Frank(j,i);
             tau_Clay(i,j)=tau_Clay(j,i);
             tau_Gum(i,j)=tau_Gum(j,i);
             tau_Frank(i,j)=tau_Frank(j,i);
             tail_Upper(i,j)=tail_Upper(j,i);
             tail_Lower(i,j)= tail_Lower(j,i);
                          
        end
             theta(i,i)=1;
             theta_t(i,i)=1;
             tau_Clay(i,i)=1;
             tau_Gum(i,i)=1;
             tau_Frank(i,i)=1;
             tail_Upper(i,i)=1;
             tail_Lower(i,i)= 1;
             theta_Clay(i,i)=999;
             theta_Gum(i,i)=999;
             theta_Frank(i,i)=999;
       
 end

 
%%%% VaR based on Gaussian and t-copula %%%
G_U=zeros(1000,N,2);
G_RV=zeros(1000,N,2);
nu=5;
Portfolio=zeros(1000,2);
PVaR=zeros(2,2);

%%%%   Copula simulation in d dimentsion   %%%%%
G_U(:,:,1) =copularnd('Gaussian', theta,1000);       
G_RV(:,:,1) = norminv(G_U(:,:,1) ,0,1) +repmat(mean(Temp),1000,1);
G_U(:,:,2) =copularnd('t', theta_t,nu,1000);       
G_RV(:,:,2) = tinv(G_U(:,:,2), nu) +repmat(mean(Temp),1000,1);

Weight=Size./sum(Size); % value-weighted  

for p=1:2     % Two types of copula (Gassian and t)
    Portfolio(:,p)=G_RV(:,:,p)*Weight;
    PVaR(p,:)=quantile(Portfolio(:,p),[0.01,0.05]);
end